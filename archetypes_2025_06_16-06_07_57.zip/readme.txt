These are archetypes exported from the Clinical Knowledge Manager.
Export time: Mon Jun 16 06:07:57 CEST 2025